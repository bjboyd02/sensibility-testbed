import android, androidlog, os, time
l = androidlog.log

l("Forkbomb, naah not reallyy")
android.run("test_python.py")

