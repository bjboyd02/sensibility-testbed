# Generated from 'Resources.h'

resSysHeap = 64
resPurgeable = 32
resLocked = 16
resProtected = 8
resPreload = 4
resChanged = 2
mapReadOnly = 128
mapCompact = 64
mapChanged = 32
resSysRefBit = 7
resSysHeapBit = 6
resPurgeableBit = 5
resLockedBit = 4
resProtectedBit = 3
resPreloadBit = 2
resChangedBit = 1
mapReadOnlyBit = 7
mapCompactBit = 6
mapChangedBit = 5
kResFileNotOpened = -1
kSystemResFile = 0
kRsrcChainBelowSystemMap = 0
kRsrcChainBelowApplicationMap = 1
kRsrcChainAboveApplicationMap = 2
kRsrcChainAboveAllMaps = 4
